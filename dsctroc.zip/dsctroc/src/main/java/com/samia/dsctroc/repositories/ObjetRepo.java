package com.samia.dsctroc.repositories;

import com.samia.dsctroc.models.Objet;
import org.springframework.data.repository.CrudRepository;

public interface ObjetRepo extends CrudRepository<Objet, Integer> {
}
