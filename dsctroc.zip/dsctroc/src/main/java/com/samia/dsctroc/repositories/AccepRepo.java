package com.samia.dsctroc.repositories;

import com.samia.dsctroc.models.Accep;
import org.springframework.data.repository.CrudRepository;

public interface AccepRepo extends CrudRepository<Accep,Integer> {
}
