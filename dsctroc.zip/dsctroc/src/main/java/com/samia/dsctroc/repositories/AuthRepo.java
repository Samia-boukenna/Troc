package com.samia.dsctroc.repositories;

import com.samia.dsctroc.models.Auth;
import org.springframework.data.repository.CrudRepository;

public interface AuthRepo extends CrudRepository<Auth,Integer> {
}
