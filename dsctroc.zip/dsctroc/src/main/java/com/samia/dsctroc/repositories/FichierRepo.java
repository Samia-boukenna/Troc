package com.samia.dsctroc.repositories;

import com.samia.dsctroc.models.Fichier;
import org.springframework.data.repository.CrudRepository;

public interface FichierRepo extends CrudRepository<Fichier, Integer> {
}
